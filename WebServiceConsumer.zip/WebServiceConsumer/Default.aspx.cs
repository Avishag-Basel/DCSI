﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebServiceConsumer
{

    public partial class _Default : Page
    {
        private String username = "avicohen";
        private String password = "avicohen-3eYJL5fd";



        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnGetUserNameAndPassword_Click(object sender, EventArgs args)
        {
            String fullName = txtFullName.Text;
            String url = "http://web27.agency2000.co.il/Test/TestService.asmx?op=GetUsernameAndPassword";
            String xml = "<?xml version=\"1.0\" encoding=\"utf-8\"?> <soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\"> <soap:Body> <GetUsernameAndPassword xmlns=\"http://tempuri.org/\"> <Fullname>" + fullName + "</Fullname> </GetUsernameAndPassword> </soap:Body> </soap:Envelope>";

            postByXml(url, xml);
        }


        protected void btnSuppliersGain_Click(object sender, EventArgs args)
        {
            String url = "http://web27.agency2000.co.il/Test/TestService.asmx?op=SuppliersGain";
            String xml = "<?xml version=\"1.0\" encoding=\"utf-8\"?> <soap12:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap12=\"http://www.w3.org/2003/05/soap-envelope\"> <soap12:Body> <SuppliersGain xmlns=\"http://tempuri.org/\"> <Username>" + username + "</Username> <Password>" + password + "</Password> <Suppliers> <Supplier> <Id>1</Id> <Name>sup1</Name> <Brutto>12</Brutto> <Netto>10</Netto> </Supplier> <Supplier> <Id>2</Id> <Name>sup2</Name> <Brutto>15</Brutto> <Netto>12</Netto> </Supplier> </Suppliers> </SuppliersGain> </soap12:Body> </soap12:Envelope>"; 
            if(!String.IsNullOrEmpty(username) && !String.IsNullOrEmpty(password))
            {
                postByXml(url, xml);

            }

        }

        private void postByXml(String url, String xml)
        {
            try
            {
                Uri obj = new Uri(url);
                HttpWebRequest connection = (HttpWebRequest)WebRequest.Create(obj);
                connection.Method = "POST";
                connection.ContentType = "text/xml; charset=utf-8";
                byte[] bytes;
                bytes = System.Text.Encoding.ASCII.GetBytes(xml);
                Stream requestStream = connection.GetRequestStream();
                requestStream.Write(bytes, 0, xml.Length);
                requestStream.Close();
                HttpWebResponse response;
                response = (HttpWebResponse)connection.GetResponse();
                if (response.StatusCode == HttpStatusCode.OK)
                {
                    string content;
                    Stream responseStream = response.GetResponseStream();
                    using (StreamReader reader = new StreamReader(responseStream))
                    {
                        content = reader.ReadToEnd();
                    }
                    if(content.IndexOf(">Username") != -1 && content.IndexOf("|Password")!=-1)
                    {
                        int startName = content.IndexOf(">Username") + 10;
                        int endingName = content.IndexOf("|Password");

                    }
                    GetBtnFunctionResult.Text = content;
                }
                else
                {
                    GetBtnFunctionResult.Text = "No response";
                }

            }
            catch (Exception ex)
            {
                GetBtnFunctionResult.Text = username + ex.Message;
            }
        }

    }
}